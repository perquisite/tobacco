# -*- coding:utf-8 -*-
# @ModuleName: over_all_description
# @Function: 
# @Author: huhonghui
# @email: 1241328737@qq.com
# @Time: 2021/10/13 17:57

# over_all_info data_item :([file, ContractCheckResult])
# ContractCheckResult(contract_type, factors, factors_ok, factors_error, factors_to_inform)
import xlwt

from ContractCheckResult import ContractCheckResult
from ContractType import ContractType
import time

type_list = {
    ContractType.BuySellContract : "标准-买卖合同",
    ContractType.ConstructionContract: "标准-建设工程施工合同",
    ContractType.RentContract: "标准-租赁合同",
    ContractType.PurchaseAndWarehousingContract: "标准-采购与服务供应商入库合同",
    ContractType.PropertyManagementContract: "标准-物业管理合同",
    ContractType.NotSure: "非标准-合同",
}
Remark_dict_risk = {
    '一次性付款': ['不利于买方',
              '一次性支付全部货款将增加买方风险,建议修改为经双方协商一致，选择按照分期付款的方式进行付款：\n1、合同签订后【】个工作日内向卖方支付合同总额的【 】%(即【】元)作为预付款。\n2、所有货物交付、安装调试完成并通过验收取得验收合格文件后【】个工作日内，买方向卖方支付合同总额的【 】%(即【】元)；买方仅根据卖方提供的《送货单》对进场货物的数量进行确认，该确认不能免除卖方对所供货物应承担的质量保证责任（包括但不限于质量、规格、型号符合法律法规规定及合同约定）。卖方部分货物未交付完成的，买方该款约定的全部款项支付义务顺延至全部货物交付完毕。\n3、剩余【】%(即【】元)款项作为质保金，在交付完成后且质保期届满后，若无任何质量问题买方在【】个工作日内无息支付。'],
    '分期付款': ['(全局)不利于买卖双方',
             '分期付款期间出卖人解除合同的，可以向买受人请求支付该标的物的使用费\n分期付款期间如果买方逾期付款应该向卖方交滞纳金\n在分期付款的买卖合同中，买卖双方应注意关于“五分之一”的特别规定'],
    '发票': ['(全局)不利于买卖双方', '发票是保障买方售后和其他相关权益的重要凭证，是强有力的法定证据，尽可能完善发票条款，尽量避免法律风险。建议包括发票类型、税率，时间和次数以及未按约定开具发票的法律责任。'],
    '分批次交付': ['不利于买方', '明确分批次交付的时间节点，防止卖方逾期交货，如卖方应于【】年【】月【】日前将第【】批货物送至双方约定的交货地点。'],
    '货物符合相关标准': ['不利于买方',
                 '明确的质量标准有利于避免卖方交付不符合要求的货物，如(1)卖方保证提供的货物是全新、未曾使用过的，拥有合格证的合格货物，其名称、型号、规格、数量与本合同及附件约定相符，并符合相关法律、法规、行业规范、行业惯例等标准；(2)货物包装、外观符合行业相关标准；(3)货物涉及的知识产权等没有瑕疵；(4)货物相关文件齐备（系统货物出厂合格证、保修卡、说明书、操作手册等）'],
    '货物验收': ['(全局)不利于买卖双方',
             '验收时间的长短对买卖双方的权益均存在重要影响，建议约定为(1)如为买方，建议约定为：买方应在卖方交货/安装完毕后及时对货物进行验收，并在验收文件上签字确认,买方签字确认后视为卖方交付完成。(2)如为卖方，建议约定为：买方应在卖方交货/安装完毕后【】日内完成货物验收，验收通过的，买方在验收文件上签字确认,签字确认后视为卖方交付完成。如买方在卖上述期限内未签署验收文件，则视为卖方交付完成。'],
    '保质期': ['不利于买方',
            '保质期（质保期、保修期）期间卖方责任需明确约定，防止卖方怠于履行售后服务。建议约定为(1)保质期自验收合格之日起【】个(月/年），货物自身存在保质期的，以货物自身的保质期为准。(2)保质期内，因非人为原因发生故障、破损等质量问题造成不能正常使用的，卖方负责免费维修；对买方使用不当或其他因素造成货品不能正常使用的，卖方维修时需向买方收取维修成本费用。在接到买方维修要求后【】小时内做出回应，【】小时内安排维修人员达到产品现场，【】小时内完成修复；卖方承诺如果在【】小时内无法修复，将在【】小时内提供备用产品或与买方协商延长修复期间，以保证买方日常工作不受影响。(3)保质期内卖方未按约定时间上门维修，视为授权买方组织维修，并由卖方承担所有费用和质量责任，同时加收维修费用【】%的劳务费。(4)当发生货物损坏返修的情况时，该货物的保质期将重新计算。(5)货品保质期满后，卖方仍应在收到买方通知后进行维护服务，可收取相关的成本费用，具体费用由买卖双方协商确定。'],
    '逾期交付违约责任': ['不利于买方',
                 '逾期交付天数对应的违约金等需明确约定，防止责任不明，举证困难。建议修改为：\n1、如为卖方，建议修改为：因买方过错导致逾期支付合同价款的，买方应按逾期付款部分【】‰/天的比例向卖方支付违约金；买方逾期支付合同价款超过【】日的，卖方有权选择单方面解除本合同，此时双方按照已经交付完成的货物进行结算，买方应按合同总金额的【】％向卖方支付违约金。\n2、如为买方，建议修改为：因买方过错导致逾期支付合同价款的，买方应按逾期付款部分【】‰/天的比例向卖方支付违约金；买方逾期支付合同价款超过【】日的，卖方有权选择单方面解除本合同，此时双方按照已经交付完成的货物进行结算，买方应按逾期付款部分的【】％向卖方支付违约金。'],
    '单方解除合同违约责任': ['(全局)不利于买卖双方',
                   '违约责任需明确约定，防止责任不明，举证困难。建议修改为：除本合同另有约定外，任何一方均无权擅自单方解除合同。若任何一方有违法单方解除合同行为的，无论解除行为是否生效，均须向另一方支付违约金。违约金为本合同总金额的【】%。'],
    '侵犯第三方权利违约责任': ['不利于买方',
                    '违约责任需明确约定，防止责任不明，举证困难。建议修改为：卖方保证所提供的货物或其任何一个组成部分均不会侵犯任何第三方的专利权、商标权、著作权、商业秘密等合法权利；如出现侵权情形，卖方应承担违约责任。买方有权解除本合同，卖方应退还全部已收款项，并按合同总金额的【】％向买方支付违约金。'],
}
def get_over_all_file(over_all_info, export_dir):
    print(over_all_info)
    need_to_write = [0] * len(over_all_info)

    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet('合同审查结果总览')
    worksheet.col(0).width = 256 * 30
    worksheet.col(1).width = 256 * 30
    worksheet.col(2).width = 256 * 20
    worksheet.col(3).width = 256 * 30
    worksheet.col(4).width = 256 * 30
    worksheet.col(5).width = 256 * 40
    worksheet.col(6).width = 256 * 40
    worksheet.col(7).width = 256 * 40
    worksheet.col(8).width = 256 * 40
    worksheet.col(9).width = 256 * 40
    worksheet.write(0, 0, "合同文件", header_style())
    worksheet.write(0, 1, "路径", header_style())
    worksheet.write(0, 2, "合同类型", header_style())
    worksheet.write(0, 3, "提取要素数量", header_style())
    worksheet.write(0, 4, "要素错误数量", header_style())
    worksheet.write(0, 5, "要素需要相关部门确认的数量", header_style())
    worksheet.write(0, 6, "非标准合同-完整性检查数量", header_style())
    worksheet.write(0, 7, "非标准合同-完整性缺失数量", header_style())
    worksheet.write(0, 8, "非标准合同-风险性检查数量", header_style())
    worksheet.write(0, 9, "非标准合同-风险性警示数量", header_style())

    for i in range(len(over_all_info)):
        if isinstance(over_all_info[i], list):
            file_path = over_all_info[i][0]   #such as C:/Users/12413/Desktop/买卖合同全错版1(已审查).docx
            file = file_path.split("/")[-1]
            contractCheckResult =  over_all_info[i][1]
            contract_type = contractCheckResult.type
            if contract_type == ContractType.NotSure:
                worksheet.write(i + 1, 0, file)
                worksheet.write(i + 1, 1, file_path)
                worksheet.write(i + 1, 2, type_list[contract_type], center())
                worksheet.write(i + 1, 3, "-")
                worksheet.write(i + 1, 4, "-")
                worksheet.write(i + 1, 5, "-")

                #非标准合同信息统计:完整性检查的总项目数、缺失项
                integrity_check_num = 0
                integrity_find_num = 0
                for item in contractCheckResult.factors_error.values():
                    integrity_check_num += len(item["check_lsit"])
                    integrity_find_num += sum(item["check_lsit"])
                worksheet.write(i + 1, 6, integrity_check_num)
                worksheet.write(i + 1, 7, integrity_check_num - integrity_find_num)

                #非标准合同信息统计:风险性检查的总项目数、缺失项
                risk_check_num = len(contractCheckResult.factors_to_inform.keys())
                risk_find_num = 0
                for item in contractCheckResult.factors_to_inform.values():
                    risk_find_num += item["check_lsit"][0]
                worksheet.write(i + 1, 8, risk_check_num)
                worksheet.write(i + 1, 9, risk_check_num - risk_find_num)

                # 是否需要write明细
                if integrity_check_num - integrity_find_num != 0 or risk_check_num - risk_find_num != 0:
                    need_to_write[i] = 1

            else:
                factors_error_num = len(contractCheckResult.factors_error)
                factors_to_inform_num = len(contractCheckResult.factors_to_inform)
                factors_num = len(contractCheckResult.factors)
                worksheet.write(i + 1, 0, file)
                worksheet.write(i + 1, 1, file_path)
                worksheet.write(i + 1, 2, type_list[contract_type], center())
                worksheet.write(i + 1, 3, factors_num)
                worksheet.write(i + 1, 4, factors_error_num)
                worksheet.write(i + 1, 5, factors_to_inform_num)
                worksheet.write(i + 1, 6, "-")
                worksheet.write(i + 1, 7, "-")
                worksheet.write(i + 1, 8, "-")
                worksheet.write(i + 1, 9, "-")

                # 是否需要write明细
                if factors_error_num != 0 or factors_to_inform_num != 0:
                    need_to_write[i] = 1

        if isinstance(over_all_info[i], str):
            file_path = over_all_info[i][2:]  # such as C:/Users/12413/Desktop/买卖合同全错版1(已审查).docx
            file = file_path.split("/")[-1]
            if over_all_info[i][0:2] == "空白":
                worksheet.write(i + 1, 0, file)
                worksheet.write(i + 1, 1, file_path)
                worksheet.write(i + 1, 2, "空白文件")
                worksheet.write(i + 1, 3, "-")
                worksheet.write(i + 1, 4, "-")
                worksheet.write(i + 1, 5, "-")

            if over_all_info[i][0:2] == "未知":
                worksheet.write(i + 1, 0, file)
                worksheet.write(i + 1, 1, file_path)
                worksheet.write(i + 1, 2, "合同类型不在常用合同库中")
                worksheet.write(i + 1, 3, "-")
                worksheet.write(i + 1, 4, "-")
                worksheet.write(i + 1, 5, "-")

    for i in range(len(over_all_info)):
        if isinstance(over_all_info[i], list):
            file_path = over_all_info[i][0]
            file = file_path.split("/")[-1]
            contractCheckResult = over_all_info[i][1]
            contract_type = contractCheckResult.type
            # 非标准合同检查明细标签页
            if contract_type == ContractType.NotSure:
                if need_to_write[i] == 0:
                    continue
                worksheet = workbook.add_sheet(file.split(".")[0])

                worksheet.col(0).width = 256 * 42
                worksheet.col(1).width = 256 * 32
                worksheet.col(2).width = 256 * 56

                worksheet.write(0, 0, "批注提示项", header_style())
                worksheet.write(0, 1, "问题类型", header_style())
                worksheet.write(0, 2, "描述", header_style())

                contractCheckResult = over_all_info[i][1]
                factors = contractCheckResult.factors
                factors_error = contractCheckResult.factors_error
                factors_to_inform = contractCheckResult.factors_to_inform
                line = 1
                for key in factors.keys():
                    for item in factors[key]:
                        worksheet.write(line, 0, key)
                        worksheet.write(line, 1, "完整性检查-缺失要素")
                        worksheet.write(line, 2, item)
                        line += 1
                for key in factors_to_inform:
                    info = factors_to_inform[key]
                    if info["check_flg"]:
                        worksheet.write(line, 0, key)
                        worksheet.write(line, 1, "风险性检查-风险警示")
                        worksheet.write(line, 2, Remark_dict_risk[key][0] + "\n" + Remark_dict_risk[key][1])
                        line += 1


            #标准合同
            else:
                if len(over_all_info[i][1].factors_error) == 0 and len(over_all_info[i][1].factors_to_inform) == 0 :
                    continue

                worksheet = workbook.add_sheet(file.split(".")[0])

                worksheet.col(0).width = 256 * 42
                worksheet.col(1).width = 256 * 32
                worksheet.col(2).width = 256 * 56

                worksheet.write(0, 0, "存在问题的要素名称", header_style())
                worksheet.write(0, 1, "问题级别", header_style())
                worksheet.write(0, 2, "描述", header_style())

                contractCheckResult = over_all_info[i][1]
                factors_error = contractCheckResult.factors_error
                factors_to_inform = contractCheckResult.factors_to_inform

                index = 0

                for key, value in factors_error.items():
                    index = index + 1
                    worksheet.write(index, 0, key)
                    worksheet.write(index, 1, "填写错误")
                    worksheet.write(index, 2, value)

                for key, value in factors_to_inform.items():
                    index = index + 1
                    worksheet.write(index, 0, key)
                    worksheet.write(index, 1, "内容需要相关部门审核确认")
                    worksheet.write(index, 2, value)


    name = time.strftime("%Y-%m-%d-%H-%M", time.localtime())

    workbook.save(export_dir + "/" + "审查总览" + name +'.xls')
    # workbook.close()

def header_style():
    style = xlwt.XFStyle()
    font = xlwt.Font()
    font.bold = True
    font.height = 20*14
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = 0x0D
    ali = xlwt.Alignment()
    ali.horz = 0x02
    style.font = font
    style.pattern = pattern
    style.alignment = ali
    return style

def center():
    style = xlwt.XFStyle()
    ali = xlwt.Alignment()
    ali.horz = 0x02
    style.alignment = ali
    return style

if __name__ == '__main__':
    over = []
    contract_type = ContractType.NotSure
    s = "{'合同主体信息': ['甲方住所地', '甲方统一社会信用代码/身份证号码', '甲方联系电话', '甲方电子邮件', '乙方法定代表人/负责人', '乙方住所地', '乙方统一社会信用代码/身份证号码', '乙方联系电话', '乙方电子邮箱'], '货物（标的）信息': ['规格型号', '计量单位', '总价'], '货物（标的）包装信息': ['包装材料', '包装总价'], '收货联系人信息': ['收货人姓名', '收货人联系方式'], '货物（标的）运输信息': ['运输时间', '运输方式', '运费负担', '运费保险费用承担', '运输通知'], '货物（标的）交付方式信息': ['交付方式'], '货物（标的）交付完成条件信息': ['交付完成条件'],'货物（标的）风险转移信息': ['风险转移'], '货物（标的）安装信息': ['安装时间', '安装地点', '安装费用承担'], '开票信息': ['开票类型', '开票公司名称', '纳税识别号', '地址', '电话'], '收款账户信息': ['收款开户名', '收款开户行'], '知识产权条款': ['知识产权条款']}"
    factors = eval(s)
    factors_ok = []
    # 完整性字典
    s = "{'合同主体信息': {'check_flg': False, 'flg_str': '（2）乙方交货的品种、数量、型号等若与合同约定不符，乙方应在7个工作日内无条件更换，并赔偿由此给甲方带来的损失，且不免除乙方延期交付的违约责任', 'check_lsit': [1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0]}, '货物（标的）信息': {'check_flg': False, 'flg_str': '1、货物名称、型号规格、单位、数量、单价、金额及合同价', 'check_lsit': [1, 0, 0, 1, 1, 1, 1, 0]}, '货物（标的）包装信息': {'check_flg': False, 'flg_str': '4、质量标准：乙方保证提供的产品系全新行货产品，包装完整，配件齐全，质量完好，符合国家3C认证（中国强制性产品认证制度）标准', 'check_lsit': [1, 0, 0]}, '收货联系人信息': {'check_flg': False, 'flg_str': '', 'check_lsit': [0, 0]}, '货物（标的）运输信息': {'check_flg': False, 'flg_str': '', 'check_lsit': [0, 1, 0, 0, 0, 0]}, '货物（标的）交付方式信息': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '货物（标的）交付地点信息': {'check_flg': True, 'flg_str': '2、交货地点和方式：崇州市崇阳街道蜀州中路341号崇州市烟草专卖局（分公司）', 'check_lsit': [1]}, '货物（标的）验收标准信息': {'check_flg': True, 'flg_str': '6、付款方式：货物验收合格，据实结算，在收到乙方开具合法有效全额增值税专用发票之日起30个工作日内一次性转账付清全部货款', 'check_lsit': [1]}, '货物（标的）交付完成条件信息': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '货物（标的）风险转移信息': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '货物（标的）安装信息': {'check_flg': False, 'flg_str': '', 'check_lsit': [0, 0, 0]}, '付款方式信息': {'check_flg': True, 'flg_str': '6、付款方式：货物验收合格，据实结算，在收到乙方开具合法有效全额增值税专用发票之日起30个工作日内一次性转账付清全部货款', 'check_lsit': [1]}, '开票信息': {'check_flg': False, 'flg_str': '银行账号： 51001416177051508447', 'check_lsit': [0, 0, 0, 0, 0, 1, 1]}, '收款账户信息': {'check_flg': False, 'flg_str': '银行账号： 51001416177051508447', 'check_lsit': [0, 0, 1]}, '质量保证责任信息': {'check_flg': True, 'flg_str': '非产品质量问题（人为损坏、使用不当或不可抗拒之力）造成的产品损坏不在保修范围内', 'check_lsit': [1]}, '违约责任条款约定': {'check_flg': True, 'flg_str': '（1）逾期交货或付款的，每天按合同总价的千分之三向对方支付违约金，逾期超过30日，守约方可单方解除合同并向违约方追索损失', 'check_lsit': [1]}, '送达通知条款': {'check_flg': True, 'flg_str': '每三个月进行一次远程售后回访，将所反馈问题2小时内做出回应，保证72小时内解决问题', 'check_lsit':[1]}, '保密条款': {'check_flg': True, 'flg_str': '若更换后仍与合同约定不符，乙方应向甲方支付合同总价30%的违约金，且甲方可单方解除合同', 'check_lsit': [1]}, '知识产权条款': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '不可抗力条款': {'check_flg': True, 'flg_str': '8、违约责任：双方应认真履行本合同中规定的内容，任何一方不得擅自变更，否则需承担相应的违约责任', 'check_lsit': [1]}, '争议解决条款': {'check_flg': True, 'flg_str': '9、争议解决方式：本合同在履行过程中，发生的争议由双方协商解决，在双方协商不能达成一致的情况下，任何一方都可以向崇州市人民法院提起诉讼', 'check_lsit': [1]}, '合同生效条款': {'check_flg': True, 'flg_str': '10、本合同一式肆份，甲方执叁份，乙方执壹份，自双方授权代表签字并加盖双方公章或合同专用章后生效，具有同等法律效力', 'check_lsit': [1]}, '合同变更条款': {'check_flg': True, 'flg_str': '8、违约责任：双方应认真履行本合同中规定的内容，任何一方不得擅自变更，否则需承担相应的违约责任', 'check_lsit': [1]}}"
    factors_error = eval(s)
    # 风险性字典
    s = "{'一次性付款': {'check_flg': True, 'flg_str': '6、付款方式：货物验收合格，据实结算，在收到乙方开具合法有效全额增值税专用发票之日起30个工作日内一次性转账付清全部货款', 'check_lsit': [1]}, '分期付款': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '发票': {'check_flg': True, 'flg_str': '6、付款方式：货物验收合格，据实结算，在收到乙方开具合法有效全额增值税专用发票之日起30个工作日内一次性转账付清全部货款', 'check_lsit': [1]}, '分批次交付': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '货物符合相关标准': {'check_flg': True, 'flg_str': '4、质量标准：乙方保证提供的产品系全新行货产品，包装完整，配件齐全，质量完好，符合国家3C认证（中国强制性产品认证制度）标准', 'check_lsit': [1]}, '货物验收': {'check_flg': True, 'flg_str': '3、交货时间：合同签订后20个工作日内交货并通过验收', 'check_lsit': [1]}, '保质期': {'check_flg': True, 'flg_str': '在质保期外,提供设备的更换、维修只收取零配件成本费用,不收取人工技术和服务费用，免费提供应急包的使用培训', 'check_lsit': [1]}, '逾期交付违约责任': {'check_flg': True, 'flg_str': '（1）逾期交货或付款的，每天按合同总价的千分之三向对方支付违约金，逾期超过30日，守约方可单方解除合同并向违约方追索损失', 'check_lsit': [1]}, '单方解除合同违约责任': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}, '侵犯第三方权利违约责任': {'check_flg': False, 'flg_str': '', 'check_lsit': [0]}}"
    factors_to_inform = eval(s)
    c = ContractCheckResult(contract_type, factors, factors_ok, factors_error, factors_to_inform)
    over.append(["D:/测试.doc",c])
    get_over_all_file(over,"D:")